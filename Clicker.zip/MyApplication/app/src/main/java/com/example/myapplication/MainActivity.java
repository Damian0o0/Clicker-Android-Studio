package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView value;
    int count = 0;
    boolean isAddingMode = true; // Początkowo tryb dodawania

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        value = findViewById(R.id.value);
        Switch modeSwitch = findViewById(R.id.modeSwitch);

        // Ustaw nasłuchiwanie zmiany stanu przełącznika
        modeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                isAddingMode = isChecked; // Zaktualizuj tryb na podstawie zaznaczenia
            }
        });
    }

    public void dodawanie(View v) {
        if (isAddingMode) {
            count++;
        } else {
            count--;
        }
        value.setText(String.valueOf(count));
    }

    public void reset(View view) {
        count = 0;
        value.setText("0");
    }
}
